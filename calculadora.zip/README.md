# Posicionamento de Componentes — React Native

Projeto de estudo focado em **posicionamento de componentes** usando apenas
os componentes centrais do React Native: `View`, `Text`, `SafeAreaView`,
`ScrollView` e `StyleSheet`.

## O que o projeto demonstra

1. **flexDirection** (`row` e `column`) — direção do fluxo dos elementos.
2. **justifyContent** (`space-between`, `center`) — alinhamento no eixo principal.
3. **alignItems** (`flex-end`) — alinhamento no eixo cruzado.
4. **position: 'absolute'** + `zIndex` — sobreposição livre de elementos
   (canto superior direito, inferior esquerdo e centralizado).

Cada seção tem um título, um subtítulo explicando a propriedade usada e uma
área de demonstração com caixas coloridas.

## Como rodar

Pré-requisitos: Node.js instalado e o app **Expo Go** no celular (ou um
emulador Android/iOS configurado).

```bash
npm install
npm start
```

Isso abrirá o Metro Bundler no navegador. Escaneie o QR Code com o Expo Go
(Android) ou a câmera (iOS) para abrir o app no seu celular, ou pressione
`a` / `i` no terminal para abrir num emulador Android/iOS.

## Estrutura

```
posicionamento-rn/
├── App.js          # Componente principal com todas as demonstrações
├── package.json
└── README.md
```

## Personalização

As cores e efeitos (sombra, `borderRadius`, elevação) estão todos no objeto
`styles` dentro de `App.js` — fique à vontade para trocar as cores em
`Box`/`SectionTitle` ou ajustar `justifyContent`/`alignItems` nas seções
para ver o efeito de cada propriedade em tempo real.
