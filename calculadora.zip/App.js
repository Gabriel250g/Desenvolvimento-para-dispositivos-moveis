import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

// ------------------------------------------------------------------
// Componente reutilizável para representar uma "caixinha" colorida
// ------------------------------------------------------------------
function Box({ label, color }) {
  return (
    <View style={[styles.box, { backgroundColor: color }]}>
      <Text style={styles.boxText}>{label}</Text>
    </View>
  );
}

// ------------------------------------------------------------------
// Componente reutilizável para o título de cada seção
// ------------------------------------------------------------------
function SectionTitle({ children, subtitle }) {
  return (
    <View style={styles.sectionHeader}>
      <Text style={styles.sectionTitle}>{children}</Text>
      {subtitle ? <Text style={styles.sectionSubtitle}>{subtitle}</Text> : null}
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.mainTitle}>Posicionamento no React Native</Text>
        <Text style={styles.mainSubtitle}>
          Explorando flexDirection, justifyContent, alignItems e position
        </Text>

        {/* ---------------------- FLEX DIRECTION ---------------------- */}
        <SectionTitle subtitle="flexDirection: 'row'">
          1. Direção do Flex (row)
        </SectionTitle>
        <View style={[styles.demoContainer, { flexDirection: 'row' }]}>
          <Box label="1" color="#FF6B6B" />
          <Box label="2" color="#FFA94D" />
          <Box label="3" color="#FFD93D" />
        </View>

        <SectionTitle subtitle="flexDirection: 'column'">
          2. Direção do Flex (column)
        </SectionTitle>
        <View style={[styles.demoContainer, { flexDirection: 'column' }]}>
          <Box label="1" color="#63E6BE" />
          <Box label="2" color="#66D9E8" />
          <Box label="3" color="#4DABF7" />
        </View>

        {/* ---------------------- JUSTIFY CONTENT ---------------------- */}
        <SectionTitle subtitle="justifyContent: 'space-between'">
          3. Alinhamento Principal (justifyContent)
        </SectionTitle>
        <View
          style={[
            styles.demoContainer,
            { flexDirection: 'row', justifyContent: 'space-between' },
          ]}
        >
          <Box label="A" color="#B197FC" />
          <Box label="B" color="#DA77F2" />
          <Box label="C" color="#F783AC" />
        </View>

        <SectionTitle subtitle="justifyContent: 'center'">
          4. Alinhamento Principal (center)
        </SectionTitle>
        <View
          style={[
            styles.demoContainer,
            { flexDirection: 'row', justifyContent: 'center' },
          ]}
        >
          <Box label="X" color="#69DB7C" />
          <Box label="Y" color="#38D9A9" />
        </View>

        {/* ---------------------- ALIGN ITEMS ---------------------- */}
        <SectionTitle subtitle="alignItems: 'flex-end' (eixo cruzado)">
          5. Alinhamento Cruzado (alignItems)
        </SectionTitle>
        <View
          style={[
            styles.demoContainer,
            styles.tallContainer,
            { flexDirection: 'row', alignItems: 'flex-end' },
          ]}
        >
          <Box label="1" color="#FF8787" />
          <Box label="2" color="#FFC078" />
          <Box label="3" color="#FFE066" />
        </View>

        {/* ---------------------- POSITION ABSOLUTE ---------------------- */}
        <SectionTitle subtitle="position: 'absolute' + zIndex">
          6. Posicionamento Absoluto
        </SectionTitle>
        <View style={[styles.demoContainer, styles.tallContainer, styles.relative]}>
          <View style={[styles.box, styles.baseBox, { backgroundColor: '#748FFC' }]}>
            <Text style={styles.boxText}>Base</Text>
          </View>
          <View style={styles.absoluteBoxTopRight}>
            <Text style={styles.boxText}>TR</Text>
          </View>
          <View style={styles.absoluteBoxBottomLeft}>
            <Text style={styles.boxText}>BL</Text>
          </View>
          <View style={styles.absoluteBoxCenter}>
            <Text style={styles.boxText}>Centro</Text>
          </View>
        </View>

        <Text style={styles.footer}>Feito com React Native ✦</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

// ------------------------------------------------------------------
// Estilos
// ------------------------------------------------------------------
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0F0F1A',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 60,
  },
  mainTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: '#F8F9FA',
    textAlign: 'center',
    marginTop: 10,
  },
  mainSubtitle: {
    fontSize: 14,
    color: '#ADB5BD',
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 24,
  },
  sectionHeader: {
    marginTop: 22,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: '#E9ECEF',
  },
  sectionSubtitle: {
    fontSize: 12,
    color: '#868E96',
    marginTop: 2,
    fontStyle: 'italic',
  },
  demoContainer: {
    backgroundColor: '#1A1A2E',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: '#2C2C44',
  },
  tallContainer: {
    height: 140,
  },
  relative: {
    position: 'relative',
    overflow: 'hidden',
  },
  box: {
    width: 60,
    height: 60,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.35,
    shadowRadius: 4,
    elevation: 5,
  },
  boxText: {
    color: '#0F0F1A',
    fontWeight: '800',
    fontSize: 14,
  },
  baseBox: {
    width: 80,
    height: 80,
    alignSelf: 'center',
    marginTop: 30,
  },
  absoluteBoxTopRight: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 46,
    height: 46,
    borderRadius: 8,
    backgroundColor: '#FF6B6B',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
  },
  absoluteBoxBottomLeft: {
    position: 'absolute',
    bottom: 10,
    left: 10,
    width: 46,
    height: 46,
    borderRadius: 8,
    backgroundColor: '#38D9A9',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
  },
  absoluteBoxCenter: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginTop: -20,
    marginLeft: -30,
    width: 60,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#FFD93D',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 3,
  },
  footer: {
    textAlign: 'center',
    color: '#495057',
    marginTop: 30,
    fontSize: 12,
  },
});
